﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrackerLibrary.Models
{
    public class MatchupModel
    {
        /// <summary>
        /// Represents the two teams that will compete with each other
        /// </summary>
        public List<MatchupEntryModel> Entries { get; set; } = new List<MatchupEntryModel>();
        /// <summary>
        /// Represents the winner team or winner player
        /// </summary>
        public TeamModel Winner { get; set; } = new TeamModel();
        /// <summary>
        /// Represnts the current round number
        /// </summary>
        public int MatchupRound { get; set; }
    }
}
