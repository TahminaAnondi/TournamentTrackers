namespace TrackerUI
{
    public partial class TournamentViewForm : Form
    {
        public TournamentViewForm()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}